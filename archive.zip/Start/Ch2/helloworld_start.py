# LinkedIn Learning Python course by Joe Marini
# Example file for HelloWorld

print("Hello World")

# Create a variable called name that takes in a user input
name = input("What is your name? ")

# Concatenation in a print statment
print("Nice to meet you", name)